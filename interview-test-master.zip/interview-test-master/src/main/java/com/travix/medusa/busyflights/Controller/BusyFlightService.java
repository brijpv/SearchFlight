package com.travix.medusa.busyflights.Controller;

import java.util.List;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;
import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsResponse;

public interface BusyFlightService {
	
	List<BusyFlightsResponse> searchFlight(String origin,String destination,String departureDate,String returnDate,int numberOfPassengers);
}
