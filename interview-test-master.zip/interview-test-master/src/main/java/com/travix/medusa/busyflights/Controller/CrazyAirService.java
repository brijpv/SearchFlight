package com.travix.medusa.busyflights.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;
import com.travix.medusa.busyflights.domain.crazyair.CrazyAirRequest;
import com.travix.medusa.busyflights.domain.crazyair.CrazyAirResponse;

public class CrazyAirService{
	
	List crazyFlightList=null;

	public List<CrazyAirResponse> searchFlightList(CrazyAirRequest crazyAirRequest) {
		//Return list of flights from CrazyAirService request according to the request
				//TODO : to set the request parameter and call the service.
				//origin,destination,departure date,return date,passenger count
				return crazyFlightList;
	}

	

	

}
