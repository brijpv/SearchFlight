package com.travix.medusa.busyflights.Controller;

import java.util.List;


import com.travix.medusa.busyflights.domain.toughjet.ToughJetRequest;
import com.travix.medusa.busyflights.domain.toughjet.ToughJetResponse;

public class ToughJetService{

	List toughjetFlightList = null;

	
    
	public List<ToughJetResponse> searchFlightList(ToughJetRequest toughJetRequest) {
		        //Return list of flights from CrazyAirservice
				//TODO : to set the request parameter and call the service.
				//from, to,outbloundDate,inboundDate,numberofAdults
				return toughjetFlightList;	}



	


}
