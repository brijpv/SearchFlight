package com.travix.medusa.busyflights.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;
import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsResponse;

@RestController
@RequestMapping("/search/")
public class SearchFlightWebAPI {
	
	private final BusyFlightService busyFlightService;
	
	@Autowired
	public SearchFlightWebAPI(BusyFlightService busyFlightService) {
		this.busyFlightService =busyFlightService; 
		
	}
	
@GetMapping("flights")
@ResponseBody
public List<BusyFlightsResponse> searchFlight(@RequestParam String origin,@RequestParam String destination,@RequestParam String departureDate,@RequestParam String returnDate,@RequestParam int numberOfPassengers){
	return busyFlightService.searchFlight(origin,destination,departureDate,returnDate,numberOfPassengers);
	
	/*public List<BusyFlightsResponse> searchFlight(@RequestBody BusyFlightsRequest busyFlightReq){
		return busyFlightService.searchFlight(busyFlightReq);
	*/
	
	
	
}

}
