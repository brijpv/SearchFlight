package com.travix.medusa.busyflights.Controller;

import java.util.List;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;
import com.travix.medusa.busyflights.domain.crazyair.CrazyAirResponse;
import com.travix.medusa.busyflights.domain.toughjet.ToughJetRequest;
import com.travix.medusa.busyflights.domain.toughjet.ToughJetResponse;

public interface SupplierSevice {

	List<ToughJetResponse> searchFlightList(ToughJetRequest toughJetRequest);
	

	

	
	
}
