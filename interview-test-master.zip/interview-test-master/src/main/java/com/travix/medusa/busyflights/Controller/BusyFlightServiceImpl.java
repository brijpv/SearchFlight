package com.travix.medusa.busyflights.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsRequest;
import com.travix.medusa.busyflights.domain.busyflights.BusyFlightsResponse;
import com.travix.medusa.busyflights.domain.crazyair.CrazyAirRequest;
import com.travix.medusa.busyflights.domain.crazyair.CrazyAirResponse;
import com.travix.medusa.busyflights.domain.toughjet.ToughJetRequest;
import com.travix.medusa.busyflights.domain.toughjet.ToughJetResponse;

public class BusyFlightServiceImpl  implements BusyFlightService{
	
	@Autowired
	public  ToughJetService  toughJetService;
	@Autowired
	public  CrazyAirService crazyAirService;
	
	private final List<SupplierSevice> supplierservice;
	
	BusyFlightServiceImpl(List <SupplierSevice> supplierservice){
		this.supplierservice =supplierservice;
	}
	
	BusyFlightsResponse busyFlightResponse;
	CrazyAirResponse crazyAirResponse;
	ToughJetResponse toughJetResponse;
	List<CrazyAirResponse> crazyFlightList = null;
	List<ToughJetResponse> toughtFlightList = null;
	List <BusyFlightsResponse>finalFlightList = null;
	
	
	/* Method for getting the SearchFlight 
	 * @param busyFlightReq
	 * return BusyFlightsResponse
	 */
	
	public List<BusyFlightsResponse> searchFlight(String origin,String destination,String departureDate,String returnDate,int numberOfPassengers) {
		//Call to the  CrazyFligt and get the result - set the required parameter
		//Call to the ToughjetFlight and get the result - set the required parameter
		
		//For CrazyAirRequest
		CrazyAirRequest crazyAirRequest  = new CrazyAirRequest();
		crazyAirRequest.setOrigin(origin);
		crazyAirRequest.setDestination(destination);
		crazyAirRequest.setDepartureDate(departureDate);
		crazyAirRequest.setReturnDate(returnDate);
		crazyAirRequest.setPassengerCount(numberOfPassengers);
		
		//For ToughFlightRequest
		ToughJetRequest toughJetRequest = new ToughJetRequest();
		toughJetRequest.setFrom(origin);
		toughJetRequest.setTo(destination);
		toughJetRequest.setInboundDate(departureDate);
		toughJetRequest.setOutboundDate(returnDate);
		toughJetRequest.setNumberOfAdults(numberOfPassengers);
		
		crazyFlightList= crazyAirService.searchFlightList(crazyAirRequest);
		toughtFlightList=toughJetService.searchFlightList(toughJetRequest);
		
		//Map response of crazyFlight
		mappingCrazyFlightDetails(finalFlightList,crazyFlightList);
		//Map response of ToughFlight
		mappingToughFlightDetails(finalFlightList,toughtFlightList);
		
		
		return finalFlightList;
	}
	/*
	 * Method for setting the corresponding property to the response Object
	 * @param finalFlightList, crazyFlightList
	 * return finalFlightList
	 * 
	 */
	private void mappingCrazyFlightDetails(List finalFlightList, List crazyFlightList) {
		BusyFlightsResponse busyFlightsResponse = new BusyFlightsResponse();
		//set proper response
		if(crazyFlightList != null) {
		for(int i =0 ; i < crazyFlightList.size();i++) {	
			CrazyAirResponse crazyAirResponse =(CrazyAirResponse) crazyFlightList.get(i);
			busyFlightsResponse.setAirline(crazyAirResponse.getAirline());
			busyFlightsResponse.setSupplier("CrazyAir");
			busyFlightsResponse.setFare(crazyAirResponse.getPrice());
			busyFlightsResponse.setDepartureAirportCode(crazyAirResponse.getDepartureAirportCode());
			busyFlightsResponse.setDestinationAirportCode(crazyAirResponse.getDestinationAirportCode());
			busyFlightsResponse.setDepartureDate(crazyAirResponse.getDepartureDate());
			busyFlightsResponse.setArrivaldate(crazyAirResponse.getArrivalDate());
		}
		finalFlightList.add(busyFlightsResponse);
		
	}
	}
		
	private void mappingToughFlightDetails(List finalFlightList, List toughtFlightList) {
		BusyFlightsResponse busyFlightsResponse = new BusyFlightsResponse();
		//set proper response
		if(toughtFlightList!=null) {
		for(int i =0 ; i < toughtFlightList.size();i++) {
			
			ToughJetResponse toughtFlightresponse =(ToughJetResponse) toughtFlightList.get(i);
			busyFlightsResponse.setAirline(toughtFlightresponse.getCarrier());
			busyFlightsResponse.setSupplier("ToughJet");
			busyFlightsResponse.setFare(toughtFlightresponse.getBasePrice());
			busyFlightsResponse.setDepartureAirportCode(toughtFlightresponse.getDepartureAirportName());
			busyFlightsResponse.setDestinationAirportCode(toughtFlightresponse.getArrivalAirportName());
			busyFlightsResponse.setDepartureDate(toughtFlightresponse.getInboundDateTime());
			busyFlightsResponse.setArrivaldate(toughtFlightresponse.getOutboundDateTime());
		}
		finalFlightList.add(busyFlightsResponse);
		}
	}
}
